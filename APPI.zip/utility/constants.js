var constants={
    ROUTE_PATH:"/api",
    HEADERS:{ "Content-Type": "application/json" },
    API_FORMAT_TYPES:"json"
  }
  
  module.exports=constants;