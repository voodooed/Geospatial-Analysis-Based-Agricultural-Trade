export class Crop {
    _id: string;
    cropName: string;
    price: number;
    quality: string;
    description: string;
    imageUrl: string;
    quantity: Number;
}